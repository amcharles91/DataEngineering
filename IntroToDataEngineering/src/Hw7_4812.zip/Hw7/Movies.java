package Hw7;

import java.util.ArrayList;


public class Movies {

	private int total;
	
	public int getTotal() {
		return total;
	}
	
	public void setTotal(int total) {
		this.total = total;
	}
	
	private ArrayList<Movieobj> movies;
	
	public ArrayList<Movieobj> getMovies() {
		return movies;
	}

	public void setMovies(ArrayList<Movieobj> movies) {
		this.movies = movies;
	}

}
